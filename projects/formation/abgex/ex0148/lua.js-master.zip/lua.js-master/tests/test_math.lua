local math = {}

function math.add(x, y)
    return x + y
end

assert(math.add(3,4) == 7)
