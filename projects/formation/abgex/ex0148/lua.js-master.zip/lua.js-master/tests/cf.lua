-- temperature conversion table (celsius to farenheit)

for c0=-20,50-1,10 do
	for c=c0,c0+10-1 do
	end
	
	for c=c0,c0+10-1 do
		f=(9/5)*c+32
	end
end
