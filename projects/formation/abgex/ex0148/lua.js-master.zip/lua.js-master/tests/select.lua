assert(select(2, 8, 9) == 9)
assert(select("#", 8, 9) == 2)
